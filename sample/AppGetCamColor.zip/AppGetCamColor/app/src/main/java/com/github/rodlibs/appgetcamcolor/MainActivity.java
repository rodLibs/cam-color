package com.github.rodlibs.appgetcamcolor;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.github.rodlibs.mylibgetimagecamera.CamPickerColor;
import com.github.rodlibs.mylibgetimagecamera.ColorListener;





public class MainActivity extends AppCompatActivity {

    CamPickerColor cam;
    ImageView img;
    TextView txtHexadecimal;
    TextView txtRGB;
    boolean isFront = false;
    boolean isplayPause = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        img = (ImageView) findViewById(R.id.img);
        txtHexadecimal = (TextView) findViewById(R.id.txtHexadecimal);
        txtRGB = (TextView) findViewById(R.id.txtRGB);
        FrameLayout frameLayout = (FrameLayout)findViewById(R.id.camera_preview);
        cam = new CamPickerColor(MainActivity.this,frameLayout);

        cam.setListener(new ColorListener() {
            @Override
            public void getColorHexadec(String s) {
                img.setBackgroundColor(Color.parseColor(s));
                txtHexadecimal.setText(s);
            }
            @Override
            public void getColorRGB(int r, int g, int b) {
                txtRGB.setText(r+"-"+g+"-"+b);
            }
            @Override
            public void getColor(int i) {}
        });
    }



    @Override
    protected void onResume() {
        super.onResume();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, 50);
        } else {
            cam.createCamera();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        cam.destroyCamera();
    }




    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.action_camera:
                if (isFront){
                    cam.setCameraBack();
                    isFront = false;
                }
                else {
                    cam.setCameraFront();
                    isFront = true;
                }
            break;


            case R.id.action_play_pause:
                if (isplayPause){
                    cam.resume();
                    isplayPause = false;
                }
                else {
                    cam.pause();
                    isplayPause = true;
                }
            break;
        }
        return super.onOptionsItemSelected(item);
    }




    @Override
    public void onRequestPermissionsResult(int requestCode,String permissions[], int[] grantResults) {
        switch (requestCode) {
            case 50: {
                if (grantResults.length == 1 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    cam.createCamera();
                } else {
                    Toast.makeText(MainActivity.this,"Permission denied.",Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

}
